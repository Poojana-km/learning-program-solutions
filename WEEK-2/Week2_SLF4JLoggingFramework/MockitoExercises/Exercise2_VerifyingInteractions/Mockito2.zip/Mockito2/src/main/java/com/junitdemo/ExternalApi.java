package com.junitdemo;

public interface ExternalApi {
    String getData();
}
